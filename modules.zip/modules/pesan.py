# Ayra - UserBot
# Copyright (C) 2021-2022 senpai80
#
# This file is a part of < https://github.com/senpai80/Ayra/ >
# PLease read the GNU Affero General Public License in
# <https://www.github.com/senpai80/Ayra/blob/main/LICENSE/>.
"""
✘ **Bantuan Untuk Pesan Rahasia**

๏ **Perintah:** `wspr` <username/id pengguna>
◉ **Keterangan:** Buat pesan rahasia mode inline.
"""
