# @riizzvbss
"""
✘ **Bantuan Untuk Toxic 2**

๏ **Perintah:** `ngentot`
◉ **Keterangan:** Coba sendiri.

๏ **Perintah:** `goblok`
◉ **Keterangan:** Coba sendiri.

๏ **Perintah:** `ngatain`
◉ **Keterangan:** Coba sendiri.

๏ **Perintah:** `yatim`
◉ **Keterangan:** Coba sendiri.

๏ **Perintah:** `kntl`
◉ **Keterangan:** Coba sendiri.
"""

from time import sleep

from . import ayra_cmd


@ayra_cmd(outgoing=True, pattern=r"^(n|N)gentot(?: |$)(.*)")
async def _(event):
    await event.eor("**WOYY NGENTOD!!**")
    sleep(1)
    await event.eor("**JANGAN SOK JAGOAN DAH LU**")
    sleep(1)
    await event.eor("**MUKA MASIH KAYA KONTOL AJA**")
    sleep(1)
    await event.eor("**BANGGA LU HAHAHAHA**")
    sleep(1)
    await event.eor("**COBA DEH NGACA MUKA LU KAN HINA BANGET**")
    sleep(1)
    await event.eor("**HAHAHAHA**")
    sleep(1)
    await event.eor("**MAKANYA GANTENG KONTOL**")
    sleep(1)
    await event.eor("**BIAR MUKALU GAK DIHINA TERUS**")
    sleep(1)
    await event.eor("**SAMA ORANG LAIN**")
    sleep(1)
    await event.eor("**HAHAHAHA**")


# Create by myself @localheart


@ayra_cmd(outgoing=True, pattern=r"^[gG][oO][bB][lL[oO][kK](g|G)blk(?: |$)(.*)")
async def _(event):
    await event.eor("**WOYY GOBLOK!!**")
    sleep(1)
    await event.eor("**KO LU GOBLOK BANGET SIH**")
    sleep(1)
    await event.eor("**OTAK LU TUH KAYA KONTOL**")
    sleep(1)
    await event.eor("**YANG LEMBEK KETIKA LEMAH**")
    sleep(1)
    await event.eor("**DAN KERAS KETIKA LU SANGE GOBLOK**")
    sleep(1)
    await event.eor("**HAHAHAHA**")
    sleep(1)
    await event.eor("**MAKANYA JANGAN SANGEAN MULU**")
    sleep(1)
    await event.eor("**MUKA LU AJA KAYA ASPAL JALANAN**")
    sleep(1)
    await event.eor("**EHHH SANGE NYA MAU DAPAT YANG CANTIK**")
    sleep(1)
    await event.eor("**HAHAHAHA**")


# Create by myself @localheart


@ayra_cmd(outgoing=True, pattern=r"^(n|N)gatain(?: |$)(.*)")
async def _(event):
    await event.eor("**BABI!!**")
    sleep(1)
    await event.eor("**MUKA LU KAYA BABI**")
    sleep(1)
    await event.eor("**OTAK LU TUH KAYA KONTOL**")
    sleep(1)
    await event.eor("**MUKA LU HINA BANGET**")
    sleep(1)
    await event.eor("**OTAK LU KAYA BATU**")
    sleep(1)
    await event.eor("**HAHAHAHA**")
    sleep(1)
    await event.eor("**MAKANYA JANGAN SANGEAN MULU**")
    sleep(1)
    await event.eor("**KONTOL LU AJA MASIH BENGKOK**")
    sleep(1)
    await event.eor("**EHHH SANGE NYA MAU DAPAT YANG CANTIK**")
    sleep(1)
    await event.eor("**HAHAHAHA**")


# Create by myself @localheart


@ayra_cmd(outgoing=True, pattern=r"^(y|Y)atim(?: |$)(.*)")
async def _(event):
    await event.eor("`Hai Anak Kontol 🙈, Jangan Lupa Makan Yaa`")
    sleep(1)
    await event.eor("`Jangan Bilang Lu Ga Dikasih Makan Sama Ortu 😁`")
    sleep(1)
    await event.eor("`APA PERLU GUA SANTUNIN ?? 🙈🙈 xixixi`")
    sleep(1)
    await event.eor("`OH IYAA LUPAAA, LU KAN BEBAN KELUARGA 🤣`")
    sleep(1)
    await event.eor("`MANA MUNGKIN ORTU LU PEDULII xixixi 🙈`")
    sleep(1)
    await event.eor("`KETAWA DULU BOLEH KALI YAA 😁`")
    sleep(1)
    await event.eor("`HAHAHAHAHAHAHA`")
    sleep(1)
    await event.eor("`KASIAN ORTUNYAA GAPEDULIII 🙈🤣`")
    sleep(1)
    await event.eor("`MAAF YA, CANDAA BEBANNNN xixixi 🙈`")
    sleep(1)
    await event.eor("`Tapi Bo'ong Hiyahiyahiya`")


# Create by myself @localheart


@ayra_cmd(outgoing=True, pattern=r"^[kK][nN][tT][lL](?: |$)(.*)")
async def _(event):
    await event.eor("**KONTOLL**")
    sleep(1.5)
    await event.eor("**LU ANAK KONTOLL**")
    sleep(1.5)
    await event.eor("**DI BIKIN DARI KONTOLL**")
    sleep(1.5)
    await event.eor("**MUKALU PERSIS KONTOLL**")
    sleep(1.5)
    await event.eor("**DASAR ANAK NGONTOLLLL**")
    sleep(1.5)
    await event.eor("**NOLEP KONTOLL**")
    sleep(1.5)
    await event.eor("**NGERUSUH KONTOLL**")
    sleep(1.5)
    await event.eor("**BENER BENER KONTOLL**")
    sleep(1.5)
    await event.eor("**PADAHAL LO GAPUNYA KONTOLL**")
    sleep(1.5)
    await event.eor("**MENDING LO OPERASI KONTOLL**")
    sleep(1.5)
    await event.eor("**BIAR LO PUNYA KONTOLL**")
    sleep(1.5)
    await event.eor("**KASIAN CACAD GAPUNYA KONTOLL**")
