# @riizzvbss
"""
✘ **Bantuan Untuk Toxic**

๏ **Perintah:** `A` sampai `Z`
◉ **Keterangan:** Coba Sendiri.
"""

from . import ayra_cmd


@ayra_cmd(pattern="A$")
async def _(event):
    await event.eor("ANJING LU YA KETEMU GUA TAMPOL LUUU")


@ayra_cmd(pattern="B$")
async def _(event):
    await event.eor("BANYAK TINGKAH LU, BIAR APA SI BEGITU,NAJIS CUIHHH")


@ayra_cmd(pattern="C$")
async def _(event):
    await event.eor("CIAHHHH ELAH ,MUKA KEK BABI AJA SO SO AN NYARI CEWE GUD LUKING")


@ayra_cmd(pattern="D$")
async def _(event):
    await event.eor("DASAR ANAK HINA LU ,HASIL KAWIN SILANG SETAN SAMA HANSIP KOMPLEK")


@ayra_cmd(pattern="E$")
async def _(event):
    await event.eor("EMANG YANG KEK GINI NIH HARUS DIBERI PAHAM ,ANJING LO !!")


@ayra_cmd(pattern="F$")
async def _(event):
    await event.eor("BABI!!KONTOL!!NGENTOT!!!")


@ayra_cmd(pattern="G$")
async def _(event):
    await event.eor("GANTENGAN JUGA GUA GOBLOK, NGACA NAPAH MUKA LU DAH KEK BABI AER")


@ayra_cmd(pattern="H$")
async def _(event):
    await event.eor(
        "HAHAHAHA OH INI YANG SOK JAGOAN DI TELE, BIAR APA SIH BEGITU, DASAR NOLEP GA PUNYA TEMEN ANJING, DIRUMAH JADI CUPU DITELE SOK MENINGGI KONTOL"
    )


@ayra_cmd(pattern="I$")
async def _(event):
    await event.eor("BACOTAN LU GAK BIKIN GUA TREMOR GOBLOK HAHAHAHA!!")


@ayra_cmd(pattern="J$")
async def _(event):
    await event.eor("JANCOKKKK ,NGENTOOOTTTTTTTT ,BANGSATTTTTTT ,MEMEKKKKKKKKK!!")


@ayra_cmd(pattern="K$")
async def _(event):
    await event.eor("KONTOL MASIH ITEM AJA SO SO AN NGAJAK VCS ANJING?")


@ayra_cmd(pattern="M$")
async def _(event):
    await event.eor("MEMEK LU INTEM ANJENGGG BAU TERASI IDIHHHH!!")


@ayra_cmd(pattern="N$")
async def _(event):
    await event.eor(
        "NAJISSSS INI GRUP APA KUBURAN SEPI BET NGENTOTTT ,BUBARIN AJALAH ANJING!!"
    )


@ayra_cmd(pattern="O$")
async def _(event):
    await event.eor("ORANG ANJING LUH ,KAN UDAH GUA BILANG??MAKANYA JANGAN NGEYEL!!")


@ayra_cmd(pattern="Q$")
async def _(event):
    await event.eor("GAUSAH SOKAP DEH KAMU, EMANG LU SIAPA ANJIRRR!!")


@ayra_cmd(pattern="R$")
async def _(event):
    await event.eor(
        "MAAF BUKAN JAGOAN HAHAHAH, GA KEK LU YANG SO JAGOAN , MENTAL SOSMED CUIHHHH!!"
    )


@ayra_cmd(pattern="S$")
async def _(event):
    await event.eor(
        "SANGE KOK VIRTUAL ANJING, KECIRI BET ORANG MISKIN KONTOL ,KALO MAU ENAK YA BAYAR BABI!!"
    )


@ayra_cmd(pattern="T$")
async def _(event):
    await event.eor(
        "TETEK LU TUH TEPOS GOBLOK, JANGAN SOK SOK AN TIPIS TIPIS ,IH NAJIS CUIHHH"
    )


@ayra_cmd(pattern="U$")
async def _(event):
    await event.eor("GANTENG LU BEGITU HAHHHHH???")


@ayra_cmd(pattern="V$")
async def _(event):
    await event.eor("CANTIK LU BEGITU, MUKA MSH PAKE FILTER IG JAN SO KERAS")


@ayra_cmd(pattern="W$")
async def _(event):
    await event.eor(
        "War War Tai Anjing, Ketrigger minta sharelok, Udah di sharelok Ga nyamperin,Keras di sosmed Bhakss..."
    )


@ayra_cmd(pattern="X$")
async def _(event):
    await event.eor(
        "MENTANG MENTANG PUNYA BOT MAINNYA BOT MULU!!NORAK BET SI ANJINGGGG HAHAHAHH"
    )


@ayra_cmd(pattern="Y$")
async def _(event):
    await event.eor(
        "BUAT LO KONTOL NIH KALO UDAH HINA GAUSAH SOK SOK NGEHINA HINA GUA KONTOL, GUA TERLALU SUCI BUAT LU YANG HINA ITU ADUHHH. SINI GUA LUDAHIN DLU LU BIAR DIRI LU SUCI KARENA LU TAU LUDAH GUA ITU MULIA SEKALI",
    )


@ayra_cmd(pattern="Z$")
async def _(event):
    await event.eor(
        "EH TOLOL LU LAGI NGATAIN DIRI SENDIRI YEH WKWKWK KASIAN BATT KASIAN BARU LIAT MUKA LU AJA UDAH KETEBAK KALAU LU TUH JABLAY TELE YANG HOBBY NYA TUH SUKA OMEK² DEPAN UMUM WKWK YANG KALAU DI BAYAR PAKE DUIT RECEHAN JUGA MASIH TTP DI GAS YAHHH KETAHUAN KAN MAKANYA KALAU MAU NGATAIN ORANG TUH NGACA DLU BHAAKKS EHH LUPA LU KAN KGK PUNYA KACA TOLOL ORANG MISKIN YANG BERLAGAK ORANG KAYA MANA PUNYA KACA WKWK"
    )
